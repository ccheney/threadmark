// src/shared/chatgpt.ts
var CHATGPT_THREAD_PREFIX = "chatgpt:";
function getChatGptConversationId(rawUrl) {
  try {
    const url = new URL(rawUrl);
    if (!url.hostname.endsWith("chatgpt.com"))
      return null;
    const segments = url.pathname.split("/").filter(Boolean);
    const conversationMarkerIndex = segments.indexOf("c");
    const conversationId = conversationMarkerIndex >= 0 ? segments[conversationMarkerIndex + 1] : undefined;
    return conversationId || null;
  } catch {
    return null;
  }
}
function getThreadIdForUrl(rawUrl) {
  if (rawUrl.startsWith(CHATGPT_THREAD_PREFIX))
    return rawUrl;
  const conversationId = getChatGptConversationId(rawUrl);
  if (conversationId)
    return `${CHATGPT_THREAD_PREFIX}${conversationId}`;
  return normalizeThreadUrl(rawUrl);
}
function normalizeThreadUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    const conversationId = getChatGptConversationId(rawUrl);
    url.hash = "";
    url.search = "";
    if (conversationId) {
      url.pathname = `/c/${conversationId}`;
    }
    return url.toString();
  } catch {
    return rawUrl;
  }
}
function urlsReferToSameThread(left, right) {
  return getThreadIdForUrl(left) === getThreadIdForUrl(right);
}

// node_modules/idb/build/index.js
var instanceOfAny = (object, constructors) => constructors.some((c) => object instanceof c);
var idbProxyableTypes;
var cursorAdvanceMethods;
function getIdbProxyableTypes() {
  return idbProxyableTypes || (idbProxyableTypes = [
    IDBDatabase,
    IDBObjectStore,
    IDBIndex,
    IDBCursor,
    IDBTransaction
  ]);
}
function getCursorAdvanceMethods() {
  return cursorAdvanceMethods || (cursorAdvanceMethods = [
    IDBCursor.prototype.advance,
    IDBCursor.prototype.continue,
    IDBCursor.prototype.continuePrimaryKey
  ]);
}
var transactionDoneMap = new WeakMap;
var transformCache = new WeakMap;
var reverseTransformCache = new WeakMap;
function promisifyRequest(request) {
  const promise = new Promise((resolve, reject) => {
    const unlisten = () => {
      request.removeEventListener("success", success);
      request.removeEventListener("error", error);
    };
    const success = () => {
      resolve(wrap(request.result));
      unlisten();
    };
    const error = () => {
      reject(request.error);
      unlisten();
    };
    request.addEventListener("success", success);
    request.addEventListener("error", error);
  });
  reverseTransformCache.set(promise, request);
  return promise;
}
function cacheDonePromiseForTransaction(tx) {
  if (transactionDoneMap.has(tx))
    return;
  const done = new Promise((resolve, reject) => {
    const unlisten = () => {
      tx.removeEventListener("complete", complete);
      tx.removeEventListener("error", error);
      tx.removeEventListener("abort", error);
    };
    const complete = () => {
      resolve();
      unlisten();
    };
    const error = () => {
      reject(tx.error || new DOMException("AbortError", "AbortError"));
      unlisten();
    };
    tx.addEventListener("complete", complete);
    tx.addEventListener("error", error);
    tx.addEventListener("abort", error);
  });
  transactionDoneMap.set(tx, done);
}
var idbProxyTraps = {
  get(target, prop, receiver) {
    if (target instanceof IDBTransaction) {
      if (prop === "done")
        return transactionDoneMap.get(target);
      if (prop === "store") {
        return receiver.objectStoreNames[1] ? undefined : receiver.objectStore(receiver.objectStoreNames[0]);
      }
    }
    return wrap(target[prop]);
  },
  set(target, prop, value) {
    target[prop] = value;
    return true;
  },
  has(target, prop) {
    if (target instanceof IDBTransaction && (prop === "done" || prop === "store")) {
      return true;
    }
    return prop in target;
  }
};
function replaceTraps(callback) {
  idbProxyTraps = callback(idbProxyTraps);
}
function wrapFunction(func) {
  if (getCursorAdvanceMethods().includes(func)) {
    return function(...args) {
      func.apply(unwrap(this), args);
      return wrap(this.request);
    };
  }
  return function(...args) {
    return wrap(func.apply(unwrap(this), args));
  };
}
function transformCachableValue(value) {
  if (typeof value === "function")
    return wrapFunction(value);
  if (value instanceof IDBTransaction)
    cacheDonePromiseForTransaction(value);
  if (instanceOfAny(value, getIdbProxyableTypes()))
    return new Proxy(value, idbProxyTraps);
  return value;
}
function wrap(value) {
  if (value instanceof IDBRequest)
    return promisifyRequest(value);
  if (transformCache.has(value))
    return transformCache.get(value);
  const newValue = transformCachableValue(value);
  if (newValue !== value) {
    transformCache.set(value, newValue);
    reverseTransformCache.set(newValue, value);
  }
  return newValue;
}
var unwrap = (value) => reverseTransformCache.get(value);
function openDB(name, version, { blocked, upgrade, blocking, terminated } = {}) {
  const request = indexedDB.open(name, version);
  const openPromise = wrap(request);
  if (upgrade) {
    request.addEventListener("upgradeneeded", (event) => {
      upgrade(wrap(request.result), event.oldVersion, event.newVersion, wrap(request.transaction), event);
    });
  }
  if (blocked) {
    request.addEventListener("blocked", (event) => blocked(event.oldVersion, event.newVersion, event));
  }
  openPromise.then((db) => {
    if (terminated)
      db.addEventListener("close", () => terminated());
    if (blocking) {
      db.addEventListener("versionchange", (event) => blocking(event.oldVersion, event.newVersion, event));
    }
  }).catch(() => {});
  return openPromise;
}
var readMethods = ["get", "getKey", "getAll", "getAllKeys", "count"];
var writeMethods = ["put", "add", "delete", "clear"];
var cachedMethods = new Map;
function getMethod(target, prop) {
  if (!(target instanceof IDBDatabase && !(prop in target) && typeof prop === "string")) {
    return;
  }
  if (cachedMethods.get(prop))
    return cachedMethods.get(prop);
  const targetFuncName = prop.replace(/FromIndex$/, "");
  const useIndex = prop !== targetFuncName;
  const isWrite = writeMethods.includes(targetFuncName);
  if (!(targetFuncName in (useIndex ? IDBIndex : IDBObjectStore).prototype) || !(isWrite || readMethods.includes(targetFuncName))) {
    return;
  }
  const method = async function(storeName, ...args) {
    const tx = this.transaction(storeName, isWrite ? "readwrite" : "readonly");
    let target2 = tx.store;
    if (useIndex)
      target2 = target2.index(args.shift());
    return (await Promise.all([
      target2[targetFuncName](...args),
      isWrite && tx.done
    ]))[0];
  };
  cachedMethods.set(prop, method);
  return method;
}
replaceTraps((oldTraps) => ({
  ...oldTraps,
  get: (target, prop, receiver) => getMethod(target, prop) || oldTraps.get(target, prop, receiver),
  has: (target, prop) => !!getMethod(target, prop) || oldTraps.has(target, prop)
}));
var advanceMethodProps = ["continue", "continuePrimaryKey", "advance"];
var methodMap = {};
var advanceResults = new WeakMap;
var ittrProxiedCursorToOriginalProxy = new WeakMap;
var cursorIteratorTraps = {
  get(target, prop) {
    if (!advanceMethodProps.includes(prop))
      return target[prop];
    let cachedFunc = methodMap[prop];
    if (!cachedFunc) {
      cachedFunc = methodMap[prop] = function(...args) {
        advanceResults.set(this, ittrProxiedCursorToOriginalProxy.get(this)[prop](...args));
      };
    }
    return cachedFunc;
  }
};
async function* iterate(...args) {
  let cursor = this;
  if (!(cursor instanceof IDBCursor)) {
    cursor = await cursor.openCursor(...args);
  }
  if (!cursor)
    return;
  cursor = cursor;
  const proxiedCursor = new Proxy(cursor, cursorIteratorTraps);
  ittrProxiedCursorToOriginalProxy.set(proxiedCursor, cursor);
  reverseTransformCache.set(proxiedCursor, unwrap(cursor));
  while (cursor) {
    yield proxiedCursor;
    cursor = await (advanceResults.get(proxiedCursor) || cursor.continue());
    advanceResults.delete(proxiedCursor);
  }
}
function isIteratorProp(target, prop) {
  return prop === Symbol.asyncIterator && instanceOfAny(target, [IDBIndex, IDBObjectStore, IDBCursor]) || prop === "iterate" && instanceOfAny(target, [IDBIndex, IDBObjectStore]);
}
replaceTraps((oldTraps) => ({
  ...oldTraps,
  get(target, prop, receiver) {
    if (isIteratorProp(target, prop))
      return iterate;
    return oldTraps.get(target, prop, receiver);
  },
  has(target, prop) {
    return isIteratorProp(target, prop) || oldTraps.has(target, prop);
  }
}));

// src/shared/db/index.ts
var DB_NAME = "threadmark-db";
var DB_VERSION = 1;
var dbPromise;
function initDB() {
  if (!dbPromise) {
    dbPromise = openDB(DB_NAME, DB_VERSION, {
      upgrade(db) {
        if (!db.objectStoreNames.contains("threads")) {
          const threadStore = db.createObjectStore("threads", {
            keyPath: "threadId"
          });
          threadStore.createIndex("by-url", "url", { unique: false });
        }
        if (!db.objectStoreNames.contains("bookmarks")) {
          const bookmarkStore = db.createObjectStore("bookmarks", {
            keyPath: "bookmarkId"
          });
          bookmarkStore.createIndex("by-threadId", "threadId", {
            unique: false
          });
        }
      }
    });
  }
  return dbPromise;
}
async function saveBookmark(payload) {
  const db = await initDB();
  const url = normalizeThreadUrl(payload.url);
  const threadId = getThreadIdForUrl(payload.url);
  let thread = await db.get("threads", threadId);
  if (!thread) {
    thread = {
      threadId,
      url,
      title: payload.title || "Untitled Chat",
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    await db.put("threads", thread);
    console.log("Threadmark: Created new thread", threadId);
  } else {
    thread.updatedAt = Date.now();
    if (payload.title && payload.title !== thread.title) {
      thread.title = payload.title;
    }
    await db.put("threads", thread);
  }
  const bookmark = {
    bookmarkId: crypto.randomUUID(),
    threadId: thread.threadId,
    text: payload.text,
    prefix: payload.prefix || "",
    suffix: payload.suffix || "",
    createdAt: payload.timestamp || Date.now(),
    tags: payload.tags || [],
    occurrence: payload.occurrence
  };
  await db.put("bookmarks", bookmark);
  console.log("Threadmark: Saved bookmark", bookmark.bookmarkId);
  return bookmark;
}

// src/background.ts
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((error) => console.error(error));
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  console.log("Threadmark: Background received message", message);
  if (message.type === "PING") {
    console.log("Threadmark: Sending PONG.");
    sendResponse({ type: "PONG" });
  } else if (message.type === "GET_BOOKMARKS_FOR_URL") {
    const url = message.url;
    initDB().then(async (db) => {
      const bookmarks = await db.getAll("bookmarks");
      const matched = bookmarks.filter((b) => urlsReferToSameThread(url, b.threadId));
      sendResponse({ bookmarks: matched });
    });
    return true;
  } else if (message.type === "BOOKMARK_REQUESTED") {
    console.log("Threadmark: Background received BOOKMARK_REQUESTED", message.payload);
    saveBookmark(message.payload).then((bookmark) => {
      console.log("Threadmark: Bookmark saved successfully:", bookmark.bookmarkId);
      chrome.runtime.sendMessage({ type: "BOOKMARK_SAVED", bookmarkId: bookmark.bookmarkId }, (_response) => {
        if (chrome.runtime.lastError) {
          console.warn("Threadmark: Could not broadcast BOOKMARK_SAVED (no listeners?):", chrome.runtime.lastError.message);
        } else {
          console.log("Threadmark: Broadcasted BOOKMARK_SAVED");
        }
      });
      sendResponse({ success: true, bookmarkId: bookmark.bookmarkId });
    }).catch((err) => {
      console.error("Threadmark: Failed to save bookmark", err);
      sendResponse({ success: false, error: err.message });
    });
    return true;
  }
  return true;
});
