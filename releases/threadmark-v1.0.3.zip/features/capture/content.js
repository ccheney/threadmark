// src/features/capture/modules/scroll_map.ts
var scrollMapContainer = null;
var scrollContainer = null;
var scrollResizeObserver = null;
function getScrollContainer() {
  if (document.documentElement.scrollTop > 0 || document.body.scrollTop > 0) {
    return window;
  }
  const divs = document.querySelectorAll("div");
  let bestCandidate = null;
  let maxScrollHeight = 0;
  divs.forEach((div) => {
    const style = window.getComputedStyle(div);
    if (style.overflowY === "auto" || style.overflowY === "scroll") {
      if (div.scrollHeight > div.clientHeight && div.scrollHeight > maxScrollHeight) {
        maxScrollHeight = div.scrollHeight;
        bestCandidate = div;
      }
    }
  });
  return bestCandidate || window;
}
function initScrollMap() {
  if (scrollMapContainer)
    return;
  scrollMapContainer = document.createElement("div");
  scrollMapContainer.id = "threadmark-scrollmap";
  Object.assign(scrollMapContainer.style, {
    position: "fixed",
    top: "0",
    right: "0",
    width: "16px",
    height: "100vh",
    zIndex: "9999",
    pointerEvents: "none"
  });
  document.body.appendChild(scrollMapContainer);
  scrollContainer = getScrollContainer();
  if (scrollContainer instanceof HTMLElement) {
    scrollResizeObserver = new ResizeObserver(() => {
      updateScrollMap();
    });
    scrollResizeObserver.observe(scrollContainer);
    scrollResizeObserver.observe(document.body);
  } else {
    window.addEventListener("resize", updateScrollMap);
  }
}
function updateScrollMap() {
  if (!scrollMapContainer)
    initScrollMap();
  if (!scrollMapContainer)
    return;
  scrollMapContainer.innerHTML = "";
  const highlights = document.querySelectorAll(".threadmark-highlight");
  if (highlights.length === 0)
    return;
  let scrollHeight = 0;
  let clientHeight = 0;
  if (scrollContainer instanceof HTMLElement) {
    scrollHeight = scrollContainer.scrollHeight;
    clientHeight = scrollContainer.clientHeight;
  } else {
    scrollHeight = document.documentElement.scrollHeight;
    clientHeight = window.innerHeight;
  }
  if (scrollHeight <= clientHeight)
    return;
  highlights.forEach((hl) => {
    const el = hl;
    let top = 0;
    if (scrollContainer instanceof HTMLElement) {
      const rect = el.getBoundingClientRect();
      const containerRect = scrollContainer.getBoundingClientRect();
      top = scrollContainer.scrollTop + (rect.top - containerRect.top);
    } else {
      const rect = el.getBoundingClientRect();
      top = window.scrollY + rect.top;
    }
    const ratio = top / scrollHeight;
    const percentage = ratio * 100;
    const marker = document.createElement("div");
    Object.assign(marker.style, {
      position: "absolute",
      top: `${percentage}%`,
      right: "2px",
      width: "12px",
      height: "4px",
      backgroundColor: "#ffd700",
      borderRadius: "2px",
      cursor: "pointer",
      pointerEvents: "auto",
      boxShadow: "0 0 2px rgba(0,0,0,0.5)",
      zIndex: "10000"
    });
    marker.title = "Go to bookmark";
    marker.addEventListener("click", (e) => {
      e.stopPropagation();
      e.preventDefault();
      el.scrollIntoView({ behavior: "smooth", block: "center" });
    });
    scrollMapContainer?.appendChild(marker);
  });
}

// src/features/capture/modules/highlighter.ts
function clearHighlights() {
  const highlights = document.querySelectorAll(".threadmark-highlight");
  highlights.forEach((el) => {
    unwrapElement(el);
  });
  updateScrollMap();
}
function removeHighlight(text) {
  if (!text)
    return;
  const highlights = document.querySelectorAll(".threadmark-highlight");
  highlights.forEach((el) => {
    const content = el.textContent || "";
    if (text.includes(content) || content.includes(text)) {
      unwrapElement(el);
    }
  });
  updateScrollMap();
}
function unwrapElement(element) {
  const parent = element.parentNode;
  if (!parent)
    return;
  while (element.firstChild) {
    parent.insertBefore(element.firstChild, element);
  }
  parent.removeChild(element);
  parent.normalize();
}
function findAndHighlight(text, context = {}, scroll = true) {
  if (!text)
    return false;
  let candidates = findRanges(document.body, text, false, context);
  if (candidates.length === 0) {
    candidates = findRanges(document.body, text, true, context);
  }
  if (candidates.length === 0) {
    return false;
  }
  if (context.occurrence !== undefined) {
    const target = candidates[context.occurrence];
    if (target) {
      const maxScore = Math.max(...candidates.map((c) => c.score));
      if (target.score >= maxScore || maxScore === 0) {
        candidates = [target];
      }
    }
  }
  candidates.sort((a, b) => b.score - a.score);
  const bestMatch = candidates[0];
  if (!bestMatch)
    return false;
  const createdSpans = highlightRange(bestMatch.range);
  if (scroll && createdSpans.length > 0) {
    const targetSpan = createdSpans[0];
    if (!targetSpan)
      return true;
    targetSpan.scrollIntoView({ behavior: "smooth", block: "center" });
    targetSpan.style.transition = "box-shadow 0.3s";
    targetSpan.style.boxShadow = "0 0 0 4px rgba(255, 215, 0, 0.5)";
    setTimeout(() => {
      targetSpan.style.boxShadow = "none";
    }, 1000);
  }
  setTimeout(updateScrollMap, 100);
  return true;
}
function highlightRange(range) {
  const newNode = document.createElement("span");
  newNode.className = "threadmark-highlight";
  newNode.style.backgroundColor = "#ffff0040";
  newNode.style.borderBottom = "2px solid #ffd700";
  newNode.style.borderRadius = "2px";
  try {
    range.surroundContents(newNode);
    return [newNode];
  } catch (_e) {
    const fragment = range.extractContents();
    range.insertNode(fragment);
    const safeWalker = document.createTreeWalker(range.commonAncestorContainer, NodeFilter.SHOW_TEXT, {
      acceptNode: (node) => {
        if (range.intersectsNode(node))
          return NodeFilter.FILTER_ACCEPT;
        return NodeFilter.FILTER_REJECT;
      }
    });
    const nodesToWrap = [];
    let currentNode;
    while (currentNode = safeWalker.nextNode()) {
      const textNode = currentNode;
      const start = textNode === range.startContainer ? range.startOffset : 0;
      const end = textNode === range.endContainer ? range.endOffset : textNode.length;
      if (end > start) {
        nodesToWrap.push({ node: textNode, start, end });
      }
    }
    const created = [];
    for (const { node, start, end } of nodesToWrap) {
      const rangePart = document.createRange();
      rangePart.setStart(node, start);
      rangePart.setEnd(node, end);
      const span = newNode.cloneNode(false);
      rangePart.surroundContents(span);
      created.push(span);
    }
    return created;
  }
}
function findRanges(root, targetText, aggressive = false, context = {}) {
  const candidates = [];
  const textNodes = [];
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let node;
  while (node = walker.nextNode()) {
    textNodes.push(node);
  }
  let fullText = "";
  const nodeOffsets = [];
  for (const tNode of textNodes) {
    const val = tNode.nodeValue || "";
    const currentText = aggressive ? val.replace(/\s+/g, "") : val;
    if (currentText.length > 0) {
      nodeOffsets.push({
        node: tNode,
        start: fullText.length,
        end: fullText.length + currentText.length,
        originalText: val
      });
      fullText += currentText;
    }
  }
  const searchFor = aggressive ? targetText.replace(/\s+/g, "") : targetText;
  const contextPrefix = aggressive && context.prefix ? context.prefix.replace(/\s+/g, "") : context.prefix || "";
  const contextSuffix = aggressive && context.suffix ? context.suffix.replace(/\s+/g, "") : context.suffix || "";
  let searchIndex = 0;
  while (true) {
    const matchIndex = fullText.indexOf(searchFor, searchIndex);
    if (matchIndex === -1)
      break;
    const startInfo = nodeOffsets.find((n) => matchIndex >= n.start && matchIndex < n.end);
    const endIndex = matchIndex + searchFor.length;
    const endInfo = nodeOffsets.find((n) => endIndex - 1 >= n.start && endIndex - 1 < n.end);
    if (startInfo && endInfo) {
      const range = document.createRange();
      const startStrippedOffset = matchIndex - startInfo.start;
      const startRealOffset = aggressive ? mapStrippedToReal(startInfo.originalText, startStrippedOffset) : startStrippedOffset;
      const endStrippedOffset = endIndex - endInfo.start;
      const endRealOffset = aggressive ? mapStrippedToReal(endInfo.originalText, endStrippedOffset) : endStrippedOffset;
      try {
        range.setStart(startInfo.node, startRealOffset);
        range.setEnd(endInfo.node, endRealOffset);
        let score = 0;
        if (contextPrefix) {
          const docPrefix = fullText.substring(Math.max(0, matchIndex - contextPrefix.length), matchIndex);
          if (docPrefix === contextPrefix)
            score += 10;
          else if (contextPrefix.endsWith(docPrefix))
            score += 5;
        }
        if (contextSuffix) {
          const docSuffix = fullText.substring(endIndex, endIndex + contextSuffix.length);
          if (docSuffix === contextSuffix)
            score += 10;
          else if (contextSuffix.startsWith(docSuffix))
            score += 5;
        }
        candidates.push({ range, score });
      } catch (_e) {
        console.log("WARN: Threadmark: Range creation error", _e);
      }
    }
    searchIndex = matchIndex + 1;
  }
  return candidates;
}
function mapStrippedToReal(original, strippedOffset) {
  let nonSpaceCount = 0;
  for (let i = 0;i < original.length; i++) {
    const char = original[i];
    if (char && !/\s/.test(char)) {
      if (nonSpaceCount === strippedOffset)
        return i;
      nonSpaceCount++;
    }
  }
  return original.length;
}

// src/features/capture/modules/bubble.ts
var fallbackButtonElement = null;
var nativeButtonElement = null;
var tagTrayElement = null;
var toolbarObserver = null;
var fallbackTimer = null;
var observerStopTimer = null;
var escapeHandler = null;
var NATIVE_TOOLBAR_LABELS = ["Ask ChatGPT", "Start writing"];
function initBubbleListener() {
  document.addEventListener("mouseup", handleSelectionChange);
  document.addEventListener("keyup", handleSelectionChange);
  document.addEventListener("mousedown", handleOutsideClick);
}
function handleSelectionChange(event) {
  const eventTarget = event?.target;
  if (eventTarget instanceof HTMLElement && eventTarget.closest("[data-threadmark-ui='true']")) {
    return;
  }
  const selection = window.getSelection();
  if (!selection || selection.isCollapsed || selection.toString().trim() === "") {
    removeThreadmarkUi();
    return;
  }
  if (isEditingText()) {
    return;
  }
  const anchorNode = selection.anchorNode;
  if (!anchorNode?.parentElement?.closest("article, [data-message-author-role]")) {
    removeThreadmarkUi();
    return;
  }
  const text = selection.toString().trim();
  if (text.length === 0)
    return;
  const capture = createBookmarkCapture(text, selection);
  removeTagTray();
  removeNativeButton();
  removeFallbackButton();
  attachToNativeToolbar(capture);
  watchForNativeToolbar(capture, selection);
}
function handleOutsideClick(event) {
  const target = event.target;
  if (fallbackButtonElement?.contains(target) || nativeButtonElement?.contains(target) || tagTrayElement?.contains(target)) {
    return;
  }
  removeTagTray();
  removeFallbackButton();
}
function isEditingText() {
  const activeElement = document.activeElement;
  return activeElement instanceof HTMLInputElement || activeElement instanceof HTMLTextAreaElement || activeElement?.getAttribute("contenteditable") === "true";
}
function watchForNativeToolbar(capture, selection) {
  stopToolbarObserver();
  toolbarObserver = new MutationObserver(() => {
    if (attachToNativeToolbar(capture)) {
      clearFallbackTimer();
    }
  });
  toolbarObserver.observe(document.body, {
    childList: true,
    subtree: true
  });
  fallbackTimer = window.setTimeout(() => {
    if (!nativeButtonElement?.isConnected) {
      showFallbackButton(selection, capture);
    }
  }, 350);
  observerStopTimer = window.setTimeout(stopToolbarObserver, 3000);
}
function attachToNativeToolbar(capture) {
  const target = findNativeToolbarTarget();
  if (!target)
    return false;
  if (nativeButtonElement?.isConnected) {
    return true;
  }
  const button = createNativeThreadmarkButton(target.referenceButton, capture);
  target.referenceChild.insertAdjacentElement("afterend", button);
  nativeButtonElement = button;
  return true;
}
function findNativeToolbarTarget() {
  const nativeButtons = Array.from(document.querySelectorAll("button, [role='button']")).filter((element) => {
    if (element.closest("[data-threadmark-ui='true']"))
      return false;
    if (!isElementUsable(element))
      return false;
    const label = normalizeText(element.textContent ?? "");
    return NATIVE_TOOLBAR_LABELS.some((nativeLabel) => label.includes(nativeLabel.toLowerCase()));
  });
  if (nativeButtons.length === 0)
    return null;
  const sortedButtons = nativeButtons.sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
  const referenceButton = sortedButtons[sortedButtons.length - 1];
  if (!referenceButton)
    return null;
  const toolbar = findToolbarContainer(nativeButtons) ?? referenceButton.parentElement;
  if (!toolbar || toolbar === document.body)
    return null;
  const referenceChild = getDirectChild(toolbar, referenceButton) ?? referenceButton;
  return {
    toolbar,
    referenceButton,
    referenceChild
  };
}
function findToolbarContainer(nativeButtons) {
  const commonAncestor = nativeButtons.length > 1 ? getCommonAncestor(nativeButtons) : nativeButtons[0]?.parentElement;
  let element = commonAncestor;
  while (element && element !== document.body) {
    if (element instanceof HTMLElement && looksLikeToolbar(element)) {
      return element;
    }
    element = element.parentElement;
  }
  return nativeButtons[0]?.parentElement ?? null;
}
function looksLikeToolbar(element) {
  const text = normalizeText(element.textContent ?? "");
  const labelCount = NATIVE_TOOLBAR_LABELS.filter((label) => text.includes(label.toLowerCase())).length;
  const controlCount = element.querySelectorAll("button, [role='button']").length;
  const rect = element.getBoundingClientRect();
  const height = rect.height || element.offsetHeight;
  return labelCount > 0 && controlCount <= 8 && height < 140;
}
function getCommonAncestor(elements) {
  const [first, ...rest] = elements;
  if (!first)
    return null;
  let candidate = first;
  while (candidate) {
    if (rest.every((element) => candidate?.contains(element))) {
      return candidate;
    }
    candidate = candidate.parentElement;
  }
  return null;
}
function getDirectChild(parent, descendant) {
  let child = descendant;
  while (child?.parentElement && child.parentElement !== parent) {
    child = child.parentElement;
  }
  return child?.parentElement === parent ? child : null;
}
function isElementUsable(element) {
  const style = window.getComputedStyle(element);
  return element.isConnected && style.display !== "none" && style.visibility !== "hidden" && style.pointerEvents !== "none";
}
function createNativeThreadmarkButton(referenceButton, capture) {
  const button = document.createElement("button");
  button.id = "threadmark-native-button";
  button.type = "button";
  button.dataset.threadmarkUi = "true";
  button.dataset.threadmarkNativeButton = "true";
  button.title = "Save to Threadmark";
  button.setAttribute("aria-label", "Save to Threadmark");
  if (referenceButton.className) {
    button.className = referenceButton.className;
  }
  Object.assign(button.style, {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "7px",
    whiteSpace: "nowrap"
  });
  const badge = document.createElement("span");
  badge.dataset.threadmarkUi = "true";
  badge.setAttribute("aria-hidden", "true");
  Object.assign(badge.style, {
    width: "16px",
    height: "16px",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: "4px",
    background: "#f2b802",
    color: "#202123",
    fontSize: "10px",
    fontWeight: "800",
    lineHeight: "1",
    boxShadow: "inset 0 0 0 1px rgba(32, 33, 35, 0.18)"
  });
  badge.textContent = "T";
  const label = document.createElement("span");
  label.dataset.threadmarkUi = "true";
  label.textContent = "Threadmark";
  button.replaceChildren(badge, label);
  button.addEventListener("mousedown", (event) => {
    event.preventDefault();
    event.stopPropagation();
    showTagTray(capture, button);
  });
  button.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    showTagTray(capture, button);
  });
  return button;
}
function showFallbackButton(selection, capture) {
  if (fallbackButtonElement)
    removeFallbackButton();
  const range = selection.getRangeAt(0);
  const rect = range.getBoundingClientRect();
  const button = document.createElement("button");
  button.id = "threadmark-bubble";
  button.type = "button";
  button.dataset.threadmarkUi = "true";
  button.title = "Save to Threadmark";
  button.setAttribute("aria-label", "Save to Threadmark");
  Object.assign(button.style, {
    position: "fixed",
    zIndex: "2147483647",
    display: "inline-flex",
    alignItems: "center",
    gap: "7px",
    background: "#202123",
    color: "#ffffff",
    border: "1px solid #565869",
    borderRadius: "10px",
    padding: "8px 11px",
    boxShadow: "0 8px 24px rgba(0,0,0,0.28)",
    fontFamily: "Söhne, ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif",
    fontSize: "14px",
    fontWeight: "600",
    cursor: "pointer"
  });
  const badge = document.createElement("span");
  badge.textContent = "T";
  Object.assign(badge.style, {
    width: "16px",
    height: "16px",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: "4px",
    background: "#f2b802",
    color: "#202123",
    fontSize: "10px",
    fontWeight: "800"
  });
  const label = document.createElement("span");
  label.textContent = "Threadmark";
  button.replaceChildren(badge, label);
  const bubbleWidth = 136;
  const bubbleHeight = 40;
  const gap = 10;
  let top = rect.top + rect.height / 2 - bubbleHeight / 2;
  let left = rect.right + gap;
  if (left + bubbleWidth > window.innerWidth) {
    left = rect.left - bubbleWidth - gap;
  }
  if (top < 0)
    top = 10;
  if (top + bubbleHeight > window.innerHeight) {
    top = window.innerHeight - bubbleHeight - 10;
  }
  button.style.top = `${top}px`;
  button.style.left = `${left}px`;
  button.addEventListener("mousedown", (event) => {
    event.preventDefault();
    event.stopPropagation();
    showTagTray(capture, button);
  });
  button.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    showTagTray(capture, button);
  });
  document.body.appendChild(button);
  fallbackButtonElement = button;
}
function showTagTray(capture, anchor) {
  removeTagTray();
  const tray = document.createElement("div");
  tray.id = "threadmark-tag-tray";
  tray.dataset.threadmarkUi = "true";
  tray.setAttribute("role", "dialog");
  tray.setAttribute("aria-label", "Threadmark tags");
  Object.assign(tray.style, {
    position: "fixed",
    zIndex: "2147483647",
    width: "312px",
    boxSizing: "border-box",
    background: "#202123",
    color: "#ffffff",
    border: "1px solid #565869",
    borderRadius: "12px",
    padding: "10px",
    boxShadow: "0 14px 36px rgba(0,0,0,0.35)",
    fontFamily: "Söhne, ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif"
  });
  const selectedTags = new Set;
  const input = document.createElement("input");
  input.type = "text";
  input.placeholder = "Tags, comma separated...";
  Object.assign(input.style, {
    flex: "1",
    minWidth: "0",
    backgroundColor: "#40414f",
    border: "1px solid #565869",
    borderRadius: "8px",
    color: "#fff",
    padding: "8px 10px",
    fontSize: "13px",
    outline: "none"
  });
  const row = document.createElement("div");
  Object.assign(row.style, {
    display: "flex",
    alignItems: "center",
    gap: "8px"
  });
  const saveButton = document.createElement("button");
  saveButton.type = "button";
  saveButton.textContent = "Save";
  Object.assign(saveButton.style, {
    backgroundColor: "#10a37f",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    padding: "8px 13px",
    fontSize: "13px",
    fontWeight: "700",
    cursor: "pointer"
  });
  const triggerSave = () => {
    saveBookmark(capture, parseTags(input.value));
  };
  input.addEventListener("mousedown", (event) => event.stopPropagation());
  input.addEventListener("keydown", (event) => {
    event.stopPropagation();
    if (event.key === "Enter") {
      triggerSave();
    }
  });
  saveButton.addEventListener("mousedown", (event) => {
    event.preventDefault();
    event.stopPropagation();
  });
  saveButton.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    triggerSave();
  });
  row.appendChild(input);
  row.appendChild(saveButton);
  tray.appendChild(row);
  document.body.appendChild(tray);
  positionTagTray(tray, anchor);
  tagTrayElement = tray;
  populateAiTagSuggestions(capture, tray, row, input, selectedTags);
  input.focus();
  installEscapeHandler();
}
function positionTagTray(tray, anchor) {
  const anchorRect = anchor.getBoundingClientRect();
  const toolbarRect = findNativeToolbarTarget()?.toolbar.getBoundingClientRect() ?? anchorRect;
  const width = 312;
  const gap = 8;
  let left = toolbarRect.right - width;
  let top = toolbarRect.bottom + gap;
  if (left < 10)
    left = 10;
  if (left + width > window.innerWidth - 10) {
    left = window.innerWidth - width - 10;
  }
  if (top + 90 > window.innerHeight) {
    top = Math.max(10, toolbarRect.top - 98);
  }
  tray.style.left = `${left}px`;
  tray.style.top = `${top}px`;
}
function installEscapeHandler() {
  if (escapeHandler)
    return;
  escapeHandler = (event) => {
    if (event.key === "Escape") {
      window.getSelection()?.removeAllRanges();
      removeThreadmarkUi();
    }
  };
  document.addEventListener("keydown", escapeHandler);
}
function createBookmarkCapture(text, selection) {
  const context = captureContext(selection);
  const occurrence = calculateOccurrenceIndex(text, selection);
  return {
    text,
    prefix: context.prefix,
    suffix: context.suffix,
    occurrence
  };
}
function saveBookmark(capture, tags = []) {
  console.log("Threadmark: saveBookmark called. Text length:", capture.text.length);
  const payload = {
    text: capture.text,
    prefix: capture.prefix,
    suffix: capture.suffix,
    url: window.location.href,
    title: document.title,
    timestamp: Date.now(),
    occurrence: capture.occurrence,
    tags
  };
  console.log("Threadmark: Sending BOOKMARK_REQUESTED message with payload:", payload);
  findAndHighlight(capture.text, {
    prefix: capture.prefix,
    suffix: capture.suffix,
    occurrence: capture.occurrence
  }, false);
  chrome.runtime.sendMessage({
    type: "BOOKMARK_REQUESTED",
    payload
  }, (response) => {
    if (chrome.runtime.lastError) {
      console.error("Threadmark: sendMessage error:", chrome.runtime.lastError);
    } else {
      console.log("Threadmark: sendMessage response:", response);
    }
  });
  removeThreadmarkUi();
}
function calculateOccurrenceIndex(text, selection) {
  try {
    const allMatches = findRanges(document.body, text, false, {});
    if (allMatches.length <= 1)
      return;
    const selectionRange = selection.getRangeAt(0);
    for (let i = 0;i < allMatches.length; i++) {
      const match = allMatches[i];
      if (!match)
        continue;
      const matchRange = match.range;
      if (matchRange.compareBoundaryPoints(Range.START_TO_START, selectionRange) === 0) {
        return i;
      }
      if (matchRange.compareBoundaryPoints(Range.START_TO_END, selectionRange) === -1 && matchRange.compareBoundaryPoints(Range.END_TO_START, selectionRange) === 1) {
        return i;
      }
    }
  } catch (error) {
    console.error("Threadmark: Error calculating occurrence index:", error);
  }
  return;
}
function captureContext(selection) {
  try {
    const range = selection.getRangeAt(0);
    const contextLength = 150;
    let prefix = "";
    const startContainer = range.startContainer;
    if (startContainer.nodeType === Node.TEXT_NODE && startContainer.textContent) {
      const startOffset = range.startOffset;
      prefix = startContainer.textContent.substring(0, startOffset);
      if (prefix.length > contextLength) {
        prefix = `...${prefix.substring(prefix.length - contextLength)}`;
      }
    }
    let suffix = "";
    const endContainer = range.endContainer;
    if (endContainer.nodeType === Node.TEXT_NODE && endContainer.textContent) {
      const endOffset = range.endOffset;
      suffix = endContainer.textContent.substring(endOffset);
      if (suffix.length > contextLength) {
        suffix = `${suffix.substring(0, contextLength)}...`;
      }
    }
    return { prefix, suffix };
  } catch (error) {
    console.error("Threadmark: Error capturing context", error);
    return { prefix: "", suffix: "" };
  }
}
async function populateAiTagSuggestions(capture, tray, insertBefore, input, selectedTags) {
  const suggestions = await suggestTagsWithBuiltInAi(capture.text, document.title);
  if (suggestions.length === 0 || !tray.isConnected || tagTrayElement !== tray) {
    return;
  }
  const chipRow = document.createElement("div");
  chipRow.dataset.threadmarkUi = "true";
  Object.assign(chipRow.style, {
    display: "flex",
    flexWrap: "wrap",
    gap: "6px",
    marginBottom: "8px"
  });
  for (const suggestion of suggestions) {
    chipRow.appendChild(createTagChip(suggestion, input, selectedTags));
  }
  tray.insertBefore(chipRow, insertBefore);
  positionTagTray(tray, nativeButtonElement ?? fallbackButtonElement ?? tray);
}
function createTagChip(suggestion, input, selectedTags) {
  const chip = document.createElement("button");
  chip.type = "button";
  chip.dataset.threadmarkUi = "true";
  chip.textContent = `#${suggestion}`;
  Object.assign(chip.style, {
    border: "1px solid #565869",
    borderRadius: "999px",
    background: "#2f3038",
    color: "#ececf1",
    padding: "4px 8px",
    fontSize: "12px",
    fontWeight: "600",
    cursor: "pointer"
  });
  chip.addEventListener("mousedown", (event) => {
    event.preventDefault();
    event.stopPropagation();
  });
  chip.addEventListener("click", () => {
    if (selectedTags.has(suggestion)) {
      selectedTags.delete(suggestion);
      chip.style.background = "#2f3038";
      chip.style.borderColor = "#565869";
    } else {
      selectedTags.add(suggestion);
      chip.style.background = "#24483f";
      chip.style.borderColor = "#10a37f";
    }
    input.value = Array.from(selectedTags).join(", ");
    input.focus();
  });
  return chip;
}
async function suggestTagsWithBuiltInAi(text, title) {
  const promptTags = await suggestTagsWithPromptApi(text, title);
  if (promptTags.length > 0)
    return promptTags;
  return suggestTagsWithSummarizerApi(text, title);
}
async function suggestTagsWithPromptApi(text, title) {
  const languageModel = getBuiltInAiGlobal().LanguageModel;
  if (!languageModel)
    return [];
  const options = {
    expectedInputs: [{ type: "text", languages: ["en"] }],
    expectedOutputs: [{ type: "text", languages: ["en"] }]
  };
  if (!await isAiModelAvailable(() => languageModel.availability(options))) {
    return [];
  }
  let session = null;
  try {
    session = await languageModel.create();
    const responseConstraint = {
      type: "array",
      minItems: 0,
      maxItems: 4,
      items: {
        type: "string"
      }
    };
    const prompt = [
      "Generate bookmark tags for the highlighted ChatGPT snippet.",
      "Return exactly a JSON array of up to 4 short tag strings.",
      "Prefer concrete nouns, technical terms, named things, and domain phrases.",
      "Avoid generic conversational words, verbs, pronouns, and adverbs.",
      "Use lowercase kebab-case without leading #.",
      `Conversation title: ${title}`,
      `Highlighted snippet: ${text}`
    ].join(`
`);
    try {
      const constrainedResponse = await session.prompt(prompt, {
        responseConstraint,
        omitResponseConstraintInput: true
      });
      return parseAiTags(constrainedResponse);
    } catch {
      const response = await session.prompt(`${prompt}
Return JSON only.`);
      return parseAiTags(response);
    }
  } catch (error) {
    console.debug("Threadmark: Prompt API tag suggestions unavailable", error);
    return [];
  } finally {
    session?.destroy?.();
  }
}
async function suggestTagsWithSummarizerApi(text, title) {
  const summarizerFactory = getBuiltInAiGlobal().Summarizer;
  if (!summarizerFactory)
    return [];
  const options = {
    type: "key-points",
    format: "plain-text",
    length: "short",
    sharedContext: "Generate concise bookmark tag phrases for a highlighted ChatGPT snippet.",
    expectedInputLanguages: ["en-US"],
    outputLanguage: "en-US"
  };
  if (!await isAiModelAvailable(() => summarizerFactory.availability(options))) {
    return [];
  }
  let summarizer = null;
  try {
    summarizer = await summarizerFactory.create(options);
    const summary = await summarizer.summarize([`Conversation title: ${title}`, "Highlighted snippet:", text].join(`
`), {
      context: "Return up to 4 concise bookmark tags. Prefer concrete nouns, technical terms, and domain phrases. Avoid generic words."
    });
    return parseAiTags(summary);
  } catch (error) {
    console.debug("Threadmark: Summarizer API tag suggestions unavailable", error);
    return [];
  } finally {
    summarizer?.destroy?.();
  }
}
async function isAiModelAvailable(checkAvailability) {
  try {
    const availability = await checkAvailability();
    return availability !== "unavailable";
  } catch {
    return false;
  }
}
function getBuiltInAiGlobal() {
  return globalThis;
}
function parseAiTags(rawResponse) {
  const jsonText = stripCodeFence(rawResponse).trim();
  const parsedTags = parseJsonTags(jsonText);
  if (parsedTags.length > 0)
    return normalizeAiTags(parsedTags);
  return normalizeAiTags(jsonText.split(/[\n,;]+/).map((line) => line.replace(/^[-*•\d.\s]+/, "").replace(/^tags?:/i, "").trim()));
}
function parseJsonTags(jsonText) {
  try {
    const parsed = JSON.parse(jsonText);
    if (Array.isArray(parsed)) {
      return parsed.filter((item) => typeof item === "string");
    }
    if (parsed && typeof parsed === "object" && "tags" in parsed && Array.isArray(parsed.tags)) {
      return parsed.tags.filter((item) => typeof item === "string");
    }
  } catch {
    return [];
  }
  return [];
}
function normalizeAiTags(tags) {
  const normalizedTags = [];
  for (const tag of tags) {
    const normalized = tag.toLowerCase().replace(/^#+/, "").replace(/[`"'()[\]{}]/g, "").replace(/&/g, " and ").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
    if (normalized.length < 2 || normalized.length > 32 || normalizedTags.includes(normalized)) {
      continue;
    }
    normalizedTags.push(normalized);
    if (normalizedTags.length === 4)
      break;
  }
  return normalizedTags;
}
function stripCodeFence(text) {
  return text.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "");
}
function parseTags(rawTags) {
  return rawTags.split(",").map((tag) => tag.trim().replace(/^#/, "")).filter(Boolean);
}
function normalizeText(text) {
  return text.replace(/\s+/g, " ").trim().toLowerCase();
}
function removeThreadmarkUi() {
  removeTagTray();
  removeNativeButton();
  removeFallbackButton();
  stopToolbarObserver();
  if (escapeHandler) {
    document.removeEventListener("keydown", escapeHandler);
    escapeHandler = null;
  }
}
function removeTagTray() {
  tagTrayElement?.remove();
  tagTrayElement = null;
  if (escapeHandler) {
    document.removeEventListener("keydown", escapeHandler);
    escapeHandler = null;
  }
}
function removeNativeButton() {
  nativeButtonElement?.remove();
  nativeButtonElement = null;
}
function removeFallbackButton() {
  fallbackButtonElement?.remove();
  fallbackButtonElement = null;
}
function clearFallbackTimer() {
  if (fallbackTimer !== null) {
    window.clearTimeout(fallbackTimer);
    fallbackTimer = null;
  }
}
function stopToolbarObserver() {
  clearFallbackTimer();
  if (observerStopTimer !== null) {
    window.clearTimeout(observerStopTimer);
    observerStopTimer = null;
  }
  toolbarObserver?.disconnect();
  toolbarObserver = null;
}

// src/features/capture/modules/observer.ts
var pendingQueue = [];
var highlightObserver = null;
var highlightDebounce = null;
function addToPendingQueue(item) {
  pendingQueue.push(item);
}
function clearPendingQueue() {
  pendingQueue.length = 0;
}
function getPendingQueueLength() {
  return pendingQueue.length;
}
function startHighlightObserver() {
  if (highlightObserver)
    return;
  console.log("Threadmark: Starting MutationObserver for highlights");
  highlightObserver = new MutationObserver((_mutations) => {
    if (highlightDebounce)
      clearTimeout(highlightDebounce);
    highlightDebounce = setTimeout(() => {
      if (pendingQueue.length > 0) {
        processPendingHighlights();
      }
    }, 500);
  });
  highlightObserver.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true
  });
}
function processPendingHighlights() {
  if (pendingQueue.length === 0)
    return;
  const now = Date.now();
  const validItems = pendingQueue.filter((item) => item.expiresAt > now);
  const expiredCount = pendingQueue.length - validItems.length;
  if (expiredCount > 0) {
    console.log(`Threadmark: Pruned ${expiredCount} expired pending highlights.`);
  }
  pendingQueue.length = 0;
  pendingQueue.push(...validItems);
  console.log(`Threadmark: Processing ${pendingQueue.length} pending highlights...`);
  for (let i = pendingQueue.length - 1;i >= 0; i--) {
    const item = pendingQueue[i];
    if (!item)
      continue;
    const context = {
      prefix: item.prefix,
      suffix: item.suffix,
      occurrence: item.occurrence
    };
    if (findAndHighlight(item.text, context, item.scroll)) {
      console.log("Threadmark: Successfully highlighted pending item:", item.text.substring(0, 20));
      pendingQueue.splice(i, 1);
    }
  }
  if (pendingQueue.length === 0) {
    console.log("Threadmark: All pending highlights applied.");
  }
}

// src/features/capture/modules/messaging.ts
function initMessageListener() {
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "HIGHLIGHT_REQUESTED") {
      const { text, prefix, suffix, occurrence } = message.payload;
      const context = { prefix, suffix, occurrence };
      const found = findAndHighlight(text, context, true);
      if (!found) {
        console.log("Threadmark: Highlight not found immediately, adding to retry queue (30s).");
        addToPendingQueue({
          text,
          prefix,
          suffix,
          occurrence,
          expiresAt: Date.now() + 30000,
          scroll: true
        });
        startHighlightObserver();
      }
      sendResponse({ success: found });
    } else if (message.type === "HIGHLIGHT_BATCH") {
      const bookmarks = message.payload.bookmarks || [];
      const texts = message.payload.texts || [];
      console.log(`Threadmark: Received HIGHLIGHT_BATCH with ${bookmarks.length || texts.length} items.`);
      clearHighlights();
      clearPendingQueue();
      let foundCount = 0;
      if (bookmarks.length > 0) {
        bookmarks.forEach((b) => {
          const context = {
            prefix: b.prefix,
            suffix: b.suffix,
            occurrence: b.occurrence
          };
          if (findAndHighlight(b.text, context, false)) {
            foundCount++;
          } else {
            addToPendingQueue({
              text: b.text,
              ...context,
              expiresAt: Date.now() + 30000,
              scroll: false
            });
          }
        });
      } else {
        texts.forEach((text) => {
          if (findAndHighlight(text, {}, false)) {
            foundCount++;
          } else {
            addToPendingQueue({
              text,
              expiresAt: Date.now() + 30000,
              scroll: false
            });
          }
        });
      }
      if (getPendingQueueLength() > 0) {
        startHighlightObserver();
      }
      sendResponse({ success: true, count: foundCount });
    } else if (message.type === "REMOVE_HIGHLIGHT") {
      const { text } = message.payload;
      console.log("Threadmark: Removing highlight for text:", text);
      removeHighlight(text);
      sendResponse({ success: true });
    }
  });
}

// src/features/capture/content.ts
console.log("%c Threadmark: Content script loaded on ChatGPT. ", "background: #222; color: #bada55");
initBubbleListener();
initMessageListener();
chrome.runtime.sendMessage({ type: "PING" }, (response) => {
  if (chrome.runtime.lastError) {
    console.error("Threadmark: Connection error:", chrome.runtime.lastError.message);
    return;
  }
  if (response && typeof response === "object" && response.type === "PONG") {
    console.log("Threadmark: Received PONG from background script. Connection established.");
    console.log("Threadmark: Checking auto-highlight setting...");
    chrome.storage.local.get("settings", (data) => {
      if (chrome.runtime.lastError) {
        console.error("Threadmark: Storage error:", chrome.runtime.lastError);
        return;
      }
      console.log("Threadmark: Settings loaded:", data);
      const settings = data.settings || { autoHighlight: true };
      if (settings.autoHighlight !== false) {
        chrome.runtime.sendMessage({ type: "GET_BOOKMARKS_FOR_URL", url: window.location.href }, (response2) => {
          if (response2?.bookmarks) {
            console.log(`Threadmark: Auto-highlighting ${response2.bookmarks.length} items.`);
            response2.bookmarks.forEach((b) => {
              addToPendingQueue({
                text: b.text,
                prefix: b.prefix,
                suffix: b.suffix,
                occurrence: b.occurrence,
                expiresAt: Date.now() + 30000,
                scroll: false
              });
            });
            startHighlightObserver();
            processPendingHighlights();
          }
        });
      } else {
        console.log("Threadmark: Auto-highlight disabled by user.");
      }
    });
  } else {
    console.log("WARN: Threadmark: Received unexpected response:", response);
  }
});
