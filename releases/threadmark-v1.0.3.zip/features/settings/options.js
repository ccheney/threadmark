// src/features/settings/storage.ts
var DEFAULT_SETTINGS = {
  autoHighlight: true,
  theme: "system",
  storagePersistent: false
};
async function getSettings() {
  const data = await chrome.storage.local.get("settings");
  return { ...DEFAULT_SETTINGS, ...data.settings || {} };
}
async function saveSettings(settings) {
  const current = await getSettings();
  const updated = { ...current, ...settings };
  await chrome.storage.local.set({ settings: updated });
  return updated;
}

// src/features/settings/options.ts
document.addEventListener("DOMContentLoaded", async () => {
  const statusDiv = document.getElementById("storage-status");
  const btn = document.getElementById("request-persist");
  const autoHighlightCheckbox = document.getElementById("auto-highlight");
  if (!statusDiv || !btn) {
    console.error("Required elements not found in DOM");
    return;
  }
  const settings = await getSettings();
  if (autoHighlightCheckbox) {
    autoHighlightCheckbox.checked = settings.autoHighlight;
    autoHighlightCheckbox.addEventListener("change", async () => {
      await saveSettings({ autoHighlight: autoHighlightCheckbox.checked });
    });
  }
  async function checkPersistence() {
    if (navigator.storage?.persisted) {
      const isPersisted = await navigator.storage.persisted();
      updateUI(isPersisted);
    } else {
      if (statusDiv)
        statusDiv.textContent = "Storage persistence API not supported.";
    }
  }
  function updateUI(isPersisted) {
    if (!statusDiv || !btn)
      return;
    if (isPersisted) {
      statusDiv.textContent = "Storage is Persistent ✅";
      statusDiv.className = "status granted";
      btn.style.display = "none";
    } else {
      statusDiv.textContent = "Storage is NOT Persistent (Browser may clear data if low on space) ⚠️";
      statusDiv.className = "status denied";
      btn.style.display = "block";
    }
    saveSettings({ storagePersistent: isPersisted });
  }
  btn.addEventListener("click", async () => {
    if (navigator.storage?.persist) {
      const isPersisted = await navigator.storage.persist();
      updateUI(isPersisted);
    }
  });
  checkPersistence();
});
