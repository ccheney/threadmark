// src/shared/chatgpt.ts
var CHATGPT_THREAD_PREFIX = "chatgpt:";
function getChatGptConversationId(rawUrl) {
  try {
    const url = new URL(rawUrl);
    if (!url.hostname.endsWith("chatgpt.com"))
      return null;
    const segments = url.pathname.split("/").filter(Boolean);
    const conversationMarkerIndex = segments.indexOf("c");
    const conversationId = conversationMarkerIndex >= 0 ? segments[conversationMarkerIndex + 1] : undefined;
    return conversationId || null;
  } catch {
    return null;
  }
}
function getThreadIdForUrl(rawUrl) {
  if (rawUrl.startsWith(CHATGPT_THREAD_PREFIX))
    return rawUrl;
  const conversationId = getChatGptConversationId(rawUrl);
  if (conversationId)
    return `${CHATGPT_THREAD_PREFIX}${conversationId}`;
  return normalizeThreadUrl(rawUrl);
}
function normalizeThreadUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    const conversationId = getChatGptConversationId(rawUrl);
    url.hash = "";
    url.search = "";
    if (conversationId) {
      url.pathname = `/c/${conversationId}`;
    }
    return url.toString();
  } catch {
    return rawUrl;
  }
}
function urlsReferToSameThread(left, right) {
  return getThreadIdForUrl(left) === getThreadIdForUrl(right);
}

// node_modules/idb/build/index.js
var instanceOfAny = (object, constructors) => constructors.some((c) => object instanceof c);
var idbProxyableTypes;
var cursorAdvanceMethods;
function getIdbProxyableTypes() {
  return idbProxyableTypes || (idbProxyableTypes = [
    IDBDatabase,
    IDBObjectStore,
    IDBIndex,
    IDBCursor,
    IDBTransaction
  ]);
}
function getCursorAdvanceMethods() {
  return cursorAdvanceMethods || (cursorAdvanceMethods = [
    IDBCursor.prototype.advance,
    IDBCursor.prototype.continue,
    IDBCursor.prototype.continuePrimaryKey
  ]);
}
var transactionDoneMap = new WeakMap;
var transformCache = new WeakMap;
var reverseTransformCache = new WeakMap;
function promisifyRequest(request) {
  const promise = new Promise((resolve, reject) => {
    const unlisten = () => {
      request.removeEventListener("success", success);
      request.removeEventListener("error", error);
    };
    const success = () => {
      resolve(wrap(request.result));
      unlisten();
    };
    const error = () => {
      reject(request.error);
      unlisten();
    };
    request.addEventListener("success", success);
    request.addEventListener("error", error);
  });
  reverseTransformCache.set(promise, request);
  return promise;
}
function cacheDonePromiseForTransaction(tx) {
  if (transactionDoneMap.has(tx))
    return;
  const done = new Promise((resolve, reject) => {
    const unlisten = () => {
      tx.removeEventListener("complete", complete);
      tx.removeEventListener("error", error);
      tx.removeEventListener("abort", error);
    };
    const complete = () => {
      resolve();
      unlisten();
    };
    const error = () => {
      reject(tx.error || new DOMException("AbortError", "AbortError"));
      unlisten();
    };
    tx.addEventListener("complete", complete);
    tx.addEventListener("error", error);
    tx.addEventListener("abort", error);
  });
  transactionDoneMap.set(tx, done);
}
var idbProxyTraps = {
  get(target, prop, receiver) {
    if (target instanceof IDBTransaction) {
      if (prop === "done")
        return transactionDoneMap.get(target);
      if (prop === "store") {
        return receiver.objectStoreNames[1] ? undefined : receiver.objectStore(receiver.objectStoreNames[0]);
      }
    }
    return wrap(target[prop]);
  },
  set(target, prop, value) {
    target[prop] = value;
    return true;
  },
  has(target, prop) {
    if (target instanceof IDBTransaction && (prop === "done" || prop === "store")) {
      return true;
    }
    return prop in target;
  }
};
function replaceTraps(callback) {
  idbProxyTraps = callback(idbProxyTraps);
}
function wrapFunction(func) {
  if (getCursorAdvanceMethods().includes(func)) {
    return function(...args) {
      func.apply(unwrap(this), args);
      return wrap(this.request);
    };
  }
  return function(...args) {
    return wrap(func.apply(unwrap(this), args));
  };
}
function transformCachableValue(value) {
  if (typeof value === "function")
    return wrapFunction(value);
  if (value instanceof IDBTransaction)
    cacheDonePromiseForTransaction(value);
  if (instanceOfAny(value, getIdbProxyableTypes()))
    return new Proxy(value, idbProxyTraps);
  return value;
}
function wrap(value) {
  if (value instanceof IDBRequest)
    return promisifyRequest(value);
  if (transformCache.has(value))
    return transformCache.get(value);
  const newValue = transformCachableValue(value);
  if (newValue !== value) {
    transformCache.set(value, newValue);
    reverseTransformCache.set(newValue, value);
  }
  return newValue;
}
var unwrap = (value) => reverseTransformCache.get(value);
function openDB(name, version, { blocked, upgrade, blocking, terminated } = {}) {
  const request = indexedDB.open(name, version);
  const openPromise = wrap(request);
  if (upgrade) {
    request.addEventListener("upgradeneeded", (event) => {
      upgrade(wrap(request.result), event.oldVersion, event.newVersion, wrap(request.transaction), event);
    });
  }
  if (blocked) {
    request.addEventListener("blocked", (event) => blocked(event.oldVersion, event.newVersion, event));
  }
  openPromise.then((db) => {
    if (terminated)
      db.addEventListener("close", () => terminated());
    if (blocking) {
      db.addEventListener("versionchange", (event) => blocking(event.oldVersion, event.newVersion, event));
    }
  }).catch(() => {});
  return openPromise;
}
var readMethods = ["get", "getKey", "getAll", "getAllKeys", "count"];
var writeMethods = ["put", "add", "delete", "clear"];
var cachedMethods = new Map;
function getMethod(target, prop) {
  if (!(target instanceof IDBDatabase && !(prop in target) && typeof prop === "string")) {
    return;
  }
  if (cachedMethods.get(prop))
    return cachedMethods.get(prop);
  const targetFuncName = prop.replace(/FromIndex$/, "");
  const useIndex = prop !== targetFuncName;
  const isWrite = writeMethods.includes(targetFuncName);
  if (!(targetFuncName in (useIndex ? IDBIndex : IDBObjectStore).prototype) || !(isWrite || readMethods.includes(targetFuncName))) {
    return;
  }
  const method = async function(storeName, ...args) {
    const tx = this.transaction(storeName, isWrite ? "readwrite" : "readonly");
    let target2 = tx.store;
    if (useIndex)
      target2 = target2.index(args.shift());
    return (await Promise.all([
      target2[targetFuncName](...args),
      isWrite && tx.done
    ]))[0];
  };
  cachedMethods.set(prop, method);
  return method;
}
replaceTraps((oldTraps) => ({
  ...oldTraps,
  get: (target, prop, receiver) => getMethod(target, prop) || oldTraps.get(target, prop, receiver),
  has: (target, prop) => !!getMethod(target, prop) || oldTraps.has(target, prop)
}));
var advanceMethodProps = ["continue", "continuePrimaryKey", "advance"];
var methodMap = {};
var advanceResults = new WeakMap;
var ittrProxiedCursorToOriginalProxy = new WeakMap;
var cursorIteratorTraps = {
  get(target, prop) {
    if (!advanceMethodProps.includes(prop))
      return target[prop];
    let cachedFunc = methodMap[prop];
    if (!cachedFunc) {
      cachedFunc = methodMap[prop] = function(...args) {
        advanceResults.set(this, ittrProxiedCursorToOriginalProxy.get(this)[prop](...args));
      };
    }
    return cachedFunc;
  }
};
async function* iterate(...args) {
  let cursor = this;
  if (!(cursor instanceof IDBCursor)) {
    cursor = await cursor.openCursor(...args);
  }
  if (!cursor)
    return;
  cursor = cursor;
  const proxiedCursor = new Proxy(cursor, cursorIteratorTraps);
  ittrProxiedCursorToOriginalProxy.set(proxiedCursor, cursor);
  reverseTransformCache.set(proxiedCursor, unwrap(cursor));
  while (cursor) {
    yield proxiedCursor;
    cursor = await (advanceResults.get(proxiedCursor) || cursor.continue());
    advanceResults.delete(proxiedCursor);
  }
}
function isIteratorProp(target, prop) {
  return prop === Symbol.asyncIterator && instanceOfAny(target, [IDBIndex, IDBObjectStore, IDBCursor]) || prop === "iterate" && instanceOfAny(target, [IDBIndex, IDBObjectStore]);
}
replaceTraps((oldTraps) => ({
  ...oldTraps,
  get(target, prop, receiver) {
    if (isIteratorProp(target, prop))
      return iterate;
    return oldTraps.get(target, prop, receiver);
  },
  has(target, prop) {
    return isIteratorProp(target, prop) || oldTraps.has(target, prop);
  }
}));

// src/shared/db/index.ts
var DB_NAME = "threadmark-db";
var DB_VERSION = 1;
var dbPromise;
function initDB() {
  if (!dbPromise) {
    dbPromise = openDB(DB_NAME, DB_VERSION, {
      upgrade(db) {
        if (!db.objectStoreNames.contains("threads")) {
          const threadStore = db.createObjectStore("threads", {
            keyPath: "threadId"
          });
          threadStore.createIndex("by-url", "url", { unique: false });
        }
        if (!db.objectStoreNames.contains("bookmarks")) {
          const bookmarkStore = db.createObjectStore("bookmarks", {
            keyPath: "bookmarkId"
          });
          bookmarkStore.createIndex("by-threadId", "threadId", {
            unique: false
          });
        }
      }
    });
  }
  return dbPromise;
}
async function saveBookmark(payload) {
  const db = await initDB();
  const url = normalizeThreadUrl(payload.url);
  const threadId = getThreadIdForUrl(payload.url);
  let thread = await db.get("threads", threadId);
  if (!thread) {
    thread = {
      threadId,
      url,
      title: payload.title || "Untitled Chat",
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    await db.put("threads", thread);
    console.log("Threadmark: Created new thread", threadId);
  } else {
    thread.updatedAt = Date.now();
    if (payload.title && payload.title !== thread.title) {
      thread.title = payload.title;
    }
    await db.put("threads", thread);
  }
  const bookmark = {
    bookmarkId: crypto.randomUUID(),
    threadId: thread.threadId,
    text: payload.text,
    prefix: payload.prefix || "",
    suffix: payload.suffix || "",
    createdAt: payload.timestamp || Date.now(),
    tags: payload.tags || [],
    occurrence: payload.occurrence
  };
  await db.put("bookmarks", bookmark);
  console.log("Threadmark: Saved bookmark", bookmark.bookmarkId);
  return bookmark;
}

// src/features/sidepanel/modules/utils.ts
function decodeHtmlEntities(text) {
  const textArea = document.createElement("textarea");
  textArea.innerHTML = text;
  return textArea.value;
}
function escapeHtml(text) {
  const div = document.createElement("div");
  div.innerText = text;
  return div.innerHTML;
}
function truncate(str, n) {
  return str.length > n ? `${str.slice(0, n - 1)}…` : str;
}
function sendMessageWithRetry(tabId, message, retries = 3) {
  chrome.tabs.sendMessage(tabId, message, (_response) => {
    if (chrome.runtime.lastError) {
      if (retries > 0) {
        setTimeout(() => sendMessageWithRetry(tabId, message, retries - 1), 500);
      } else {
        console.log(`Threadmark: Could not send highlight message to tab ${tabId}`);
      }
    }
  });
}

// src/features/sidepanel/modules/navigation.ts
function openBookmark(bookmark, thread) {
  if (!thread || !thread.url) {
    console.error("Cannot open bookmark: missing thread URL");
    return;
  }
  const url = thread.url;
  const highlightMessage = {
    type: "HIGHLIGHT_REQUESTED",
    payload: {
      text: bookmark.text,
      prefix: bookmark.prefix,
      suffix: bookmark.suffix,
      occurrence: bookmark.occurrence
    }
  };
  chrome.tabs.query({}, (tabs) => {
    const existingTab = tabs.find((t) => t.url && urlsReferToSameThread(t.url, url));
    if (existingTab?.id !== undefined) {
      const tabId = existingTab.id;
      chrome.tabs.update(tabId, { active: true });
      if (existingTab.windowId) {
        chrome.windows.update(existingTab.windowId, { focused: true });
      }
      setTimeout(() => {
        sendMessageWithRetry(tabId, highlightMessage);
      }, 300);
    } else {
      chrome.tabs.create({ url }, (tab) => {
        if (tab.id === undefined)
          return;
        const tabId = tab.id;
        const sendWhenLoaded = (updatedTabId, changeInfo) => {
          if (updatedTabId !== tabId || changeInfo.status !== "complete") {
            return;
          }
          chrome.tabs.onUpdated.removeListener(sendWhenLoaded);
          sendMessageWithRetry(tabId, highlightMessage, 10);
        };
        chrome.tabs.onUpdated.addListener(sendWhenLoaded);
      });
    }
  });
}

// src/features/sidepanel/modules/theme.ts
function applyTheme(theme) {
  const body = document.body;
  if (theme === "dark") {
    body.classList.add("theme-dark");
  } else if (theme === "light") {
    body.classList.remove("theme-dark");
  } else {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    if (mq.matches)
      body.classList.add("theme-dark");
    else
      body.classList.remove("theme-dark");
    mq.onchange = (e) => {
      const currentVal = document.getElementById("theme-select")?.value;
      if (currentVal === "system") {
        if (e.matches)
          body.classList.add("theme-dark");
        else
          body.classList.remove("theme-dark");
      }
    };
  }
}
function updateShowAllButton(btn, hasCurrentBookmarks) {
  btn.textContent = "Highlight all";
  if (hasCurrentBookmarks) {
    btn.disabled = false;
    btn.title = "Highlight all bookmarks in this chat";
  } else {
    btn.disabled = true;
    btn.title = "No bookmarks in the current chat";
  }
}

// src/features/sidepanel/modules/bookmarks.ts
var activeScope = "current";
var currentThreadTitle = "No chat selected";
var currentTabUrl = null;
var hasCurrentChatContext = false;
var currentBookmarkCount = 0;
var libraryBookmarkCount = 0;
async function setBookmarkScope(scope) {
  activeScope = scope;
  updateScopeControls();
  await loadBookmarks();
}
async function populateChatFilter(threads) {
  const filterChat = document.getElementById("filter-chat");
  if (!filterChat)
    return;
  const currentVal = filterChat.value;
  while (filterChat.options.length > 1) {
    filterChat.remove(1);
  }
  const sortedThreads = [...threads].sort((a, b) => b.updatedAt - a.updatedAt);
  sortedThreads.forEach((t) => {
    const option = document.createElement("option");
    option.value = t.threadId;
    option.text = truncate(decodeHtmlEntities(t.title || "Untitled chat"), 30);
    filterChat.add(option);
  });
  filterChat.value = currentVal;
  if (filterChat.selectedIndex === -1) {
    filterChat.value = "all";
  }
}
async function syncSidepanelWithTab() {
  const db = await initDB();
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const currentTab = tabs[0];
  currentTabUrl = currentTab?.url ?? null;
  const threads = await db.getAll("threads");
  const bookmarks = await db.getAll("bookmarks");
  const activeThreadIds = new Set(bookmarks.map((b) => b.threadId));
  const activeThreads = threads.filter((t) => activeThreadIds.has(t.threadId));
  populateChatFilter(activeThreads);
  const matchedThread = currentTabUrl ? activeThreads.find((t) => urlsReferToSameThread(currentTabUrl ?? "", t.threadId) || urlsReferToSameThread(currentTabUrl ?? "", t.url)) : undefined;
  hasCurrentChatContext = Boolean(currentTabUrl?.includes("chatgpt.com"));
  if (matchedThread) {
    currentThreadTitle = decodeHtmlEntities(matchedThread.title || "Untitled chat");
  } else if (hasCurrentChatContext) {
    currentThreadTitle = "This chat has no bookmarks";
  } else {
    currentThreadTitle = "Open a ChatGPT conversation";
  }
  refreshBookmarkCounts(bookmarks);
  updateScopeControls();
  loadBookmarks();
}
async function loadBookmarks(query, forceReload = false) {
  if (forceReload) {
    await syncSidepanelWithTab();
    return;
  }
  const db = await initDB();
  const listElement = document.getElementById("bookmark-list");
  const emptyState = document.getElementById("empty-state");
  const filterDate = document.getElementById("filter-date");
  const filterChat = document.getElementById("filter-chat");
  const searchInput = document.getElementById("search-input");
  if (!listElement || !emptyState) {
    console.error("Sidepanel elements not found");
    return;
  }
  const rawQuery = query !== undefined ? query : searchInput?.value || "";
  const bookmarks = await db.getAll("bookmarks");
  const threads = await db.getAll("threads");
  const threadMap = new Map;
  for (const t of threads) {
    threadMap.set(t.threadId, t);
  }
  refreshBookmarkCounts(bookmarks);
  updateScopeControls();
  const dateFilterVal = filterDate ? filterDate.value : "all";
  const chatFilterVal = filterChat ? filterChat.value : "all";
  const now = Date.now();
  const oneDay = 24 * 60 * 60 * 1000;
  const lowerQuery = rawQuery.toLowerCase().trim();
  const filteredBookmarks = bookmarks.filter((bookmark) => {
    if (activeScope === "current") {
      if (!currentTabUrl || !urlsReferToSameThread(currentTabUrl, bookmark.threadId)) {
        return false;
      }
    } else if (chatFilterVal !== "all" && bookmark.threadId !== chatFilterVal) {
      return false;
    }
    if (lowerQuery) {
      const thread = threadMap.get(bookmark.threadId);
      const threadTitle = thread?.title.toLowerCase() ?? "";
      const matchesQuery = bookmark.text.toLowerCase().includes(lowerQuery) || threadTitle.includes(lowerQuery) || (bookmark.tags?.some((tag) => tag.toLowerCase().includes(lowerQuery)) ?? false);
      if (!matchesQuery)
        return false;
    }
    if (dateFilterVal !== "all") {
      const age = now - bookmark.createdAt;
      if (dateFilterVal === "today" && age > oneDay)
        return false;
      if (dateFilterVal === "7days" && age > 7 * oneDay)
        return false;
      if (dateFilterVal === "30days" && age > 30 * oneDay)
        return false;
    }
    return true;
  });
  filteredBookmarks.sort((a, b) => b.createdAt - a.createdAt);
  listElement.innerHTML = "";
  if (filteredBookmarks.length === 0) {
    emptyState.hidden = false;
    emptyState.innerText = getEmptyStateMessage(Boolean(lowerQuery));
    return;
  }
  emptyState.hidden = true;
  if (activeScope === "library") {
    renderGroupedBookmarks(filteredBookmarks, threadMap, listElement);
  } else {
    filteredBookmarks.forEach((bookmark) => {
      const thread = threadMap.get(bookmark.threadId);
      listElement.appendChild(renderBookmarkItem(bookmark, thread));
    });
  }
}
function refreshBookmarkCounts(bookmarks) {
  libraryBookmarkCount = bookmarks.length;
  currentBookmarkCount = currentTabUrl ? bookmarks.filter((bookmark) => urlsReferToSameThread(currentTabUrl ?? "", bookmark.threadId)).length : 0;
}
function updateScopeControls() {
  const currentButton = document.getElementById("scope-current");
  const libraryButton = document.getElementById("scope-library");
  const currentCount = document.getElementById("current-count");
  const libraryCount = document.getElementById("library-count");
  const scopeLabel = document.getElementById("scope-label");
  const scopeHeading = document.getElementById("scope-heading");
  const backToCurrentButton = document.getElementById("back-to-current-btn");
  const filterChatRow = document.getElementById("filter-chat-row");
  const actionRow = document.querySelector(".action-row");
  const showAllButton = document.getElementById("show-all-btn");
  currentButton?.classList.toggle("is-active", activeScope === "current");
  libraryButton?.classList.toggle("is-active", activeScope === "library");
  currentButton?.setAttribute("aria-selected", String(activeScope === "current"));
  libraryButton?.setAttribute("aria-selected", String(activeScope === "library"));
  if (currentCount)
    currentCount.textContent = String(currentBookmarkCount);
  if (libraryCount)
    libraryCount.textContent = String(libraryBookmarkCount);
  if (activeScope === "library") {
    if (scopeLabel)
      scopeLabel.textContent = "Recent bookmarks";
    if (scopeHeading) {
      scopeHeading.textContent = libraryBookmarkCount === 1 ? "1 saved bookmark" : `${libraryBookmarkCount} saved bookmarks`;
    }
  } else {
    if (scopeLabel)
      scopeLabel.textContent = "Current chat";
    if (scopeHeading)
      scopeHeading.textContent = currentThreadTitle;
  }
  if (backToCurrentButton) {
    backToCurrentButton.hidden = activeScope !== "library" || !hasCurrentChatContext;
  }
  if (filterChatRow) {
    filterChatRow.hidden = activeScope === "current";
  }
  if (actionRow) {
    actionRow.hidden = activeScope === "library";
  }
  if (showAllButton) {
    updateShowAllButton(showAllButton, hasCurrentChatContext && currentBookmarkCount > 0);
  }
}
function getEmptyStateMessage(hasQuery) {
  if (activeScope === "library") {
    if (libraryBookmarkCount === 0) {
      return "No bookmarks in your library yet. Select text in ChatGPT to save your first one.";
    }
    return hasQuery ? "No library bookmarks match your search." : "No bookmarks match these filters.";
  }
  if (!hasCurrentChatContext) {
    return "Open a ChatGPT conversation to see bookmarks for the current chat.";
  }
  if (currentBookmarkCount === 0) {
    return "No bookmarks in this chat yet. Select text in ChatGPT to save one.";
  }
  return hasQuery ? "No bookmarks in this chat match your search." : "No bookmarks in this chat match these filters.";
}
function renderGroupedBookmarks(bookmarks, threadMap, listElement) {
  const groups = new Map;
  for (const bookmark of bookmarks) {
    const group = groups.get(bookmark.threadId);
    if (group) {
      group.push(bookmark);
    } else {
      groups.set(bookmark.threadId, [bookmark]);
    }
  }
  const sortedGroups = [...groups.entries()].sort(([, a], [, b]) => (b[0]?.createdAt ?? 0) - (a[0]?.createdAt ?? 0));
  for (const [threadId, groupBookmarks] of sortedGroups) {
    const thread = threadMap.get(threadId);
    listElement.appendChild(renderThreadHeading(thread));
    for (const bookmark of groupBookmarks) {
      listElement.appendChild(renderBookmarkItem(bookmark, thread));
    }
  }
}
function renderThreadHeading(thread) {
  const li = document.createElement("li");
  li.className = "thread-group-heading";
  li.textContent = decodeHtmlEntities(thread?.title || "Unknown chat");
  return li;
}
function renderBookmarkItem(bookmark, thread) {
  const li = document.createElement("li");
  li.className = "bookmark-item";
  const dateStr = new Date(bookmark.createdAt).toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
  const threadTitle = decodeHtmlEntities(thread?.title || "Unknown chat");
  const tagsHtml = bookmark.tags && bookmark.tags.length > 0 ? `<div class="bookmark-tags">${bookmark.tags.map((tag) => `<span class="bookmark-tag">#${escapeHtml(tag)}</span>`).join("")}</div>` : "";
  li.innerHTML = `
		<div class="bookmark-content">
			<div class="bookmark-text">${escapeHtml(bookmark.text)}</div>
			${tagsHtml}
			<div class="bookmark-meta">
				<span class="bookmark-thread" title="${escapeHtml(threadTitle)}">${escapeHtml(threadTitle)}</span>
				<span>${dateStr}</span>
			</div>
		</div>
		<div class="bookmark-actions">
			<button class="bookmark-icon-btn open-btn" type="button" title="Open bookmark" aria-label="Open bookmark">
				<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
					<path d="M7 17 17 7"></path>
					<path d="M7 7h10v10"></path>
				</svg>
			</button>
			<button class="bookmark-icon-btn delete-btn" type="button" title="Delete bookmark" aria-label="Delete bookmark">
				<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
					<polyline points="3 6 5 6 21 6"></polyline>
					<path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
				</svg>
			</button>
		</div>
	`;
  li.addEventListener("click", () => openBookmark(bookmark, thread));
  const openBtn = li.querySelector(".open-btn");
  openBtn?.addEventListener("click", (event) => {
    event.stopPropagation();
    openBookmark(bookmark, thread);
  });
  const deleteBtn = li.querySelector(".delete-btn");
  deleteBtn?.addEventListener("click", (event) => {
    event.stopPropagation();
    if (confirm("Delete this bookmark?")) {
      deleteBookmark(bookmark.bookmarkId);
    }
  });
  return li;
}
async function deleteBookmark(bookmarkId) {
  const db = await initDB();
  const bookmark = await db.get("bookmarks", bookmarkId);
  if (bookmark) {
    await db.delete("bookmarks", bookmarkId);
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const currentTab = tabs[0];
      if (currentTab?.id) {
        chrome.tabs.sendMessage(currentTab.id, {
          type: "REMOVE_HIGHLIGHT",
          payload: { text: bookmark.text }
        });
      }
    });
  }
  loadBookmarks(undefined, true);
}
async function purgeAllBookmarks() {
  if (!confirm("Delete all bookmarks across all conversations? This action cannot be undone.")) {
    return;
  }
  const db = await initDB();
  const tx = db.transaction(["bookmarks", "threads"], "readwrite");
  await Promise.all([
    tx.objectStore("bookmarks").clear(),
    tx.objectStore("threads").clear(),
    tx.done
  ]);
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const currentTab = tabs[0];
    if (currentTab?.id) {
      chrome.tabs.sendMessage(currentTab.id, {
        type: "HIGHLIGHT_BATCH",
        payload: { bookmarks: [] }
      });
    }
  });
  loadBookmarks(undefined, true);
  alert("All bookmarks have been deleted.");
}
async function purgePageBookmarks() {
  if (!confirm("Delete all bookmarks for the current conversation? This action cannot be undone.")) {
    return;
  }
  chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
    const currentTab = tabs[0];
    if (!currentTab?.url) {
      alert("Open a ChatGPT conversation before deleting this chat's bookmarks.");
      return;
    }
    const db = await initDB();
    const bookmarks = await db.getAll("bookmarks");
    const relevantBookmarks = bookmarks.filter((bookmark) => urlsReferToSameThread(currentTab.url ?? "", bookmark.threadId));
    if (relevantBookmarks.length === 0) {
      alert("No bookmarks found for this chat.");
      return;
    }
    const tx = db.transaction("bookmarks", "readwrite");
    await Promise.all([
      ...relevantBookmarks.map((bookmark) => tx.store.delete(bookmark.bookmarkId)),
      tx.done
    ]);
    if (currentTab.id) {
      chrome.tabs.sendMessage(currentTab.id, {
        type: "HIGHLIGHT_BATCH",
        payload: { bookmarks: [] }
      });
    }
    loadBookmarks(undefined, true);
    alert(`Deleted ${relevantBookmarks.length} bookmarks.`);
  });
}

// src/features/settings/storage.ts
var DEFAULT_SETTINGS = {
  autoHighlight: true,
  theme: "system",
  storagePersistent: false
};
async function getSettings() {
  const data = await chrome.storage.local.get("settings");
  return { ...DEFAULT_SETTINGS, ...data.settings || {} };
}
async function saveSettings(settings) {
  const current = await getSettings();
  const updated = { ...current, ...settings };
  await chrome.storage.local.set({ settings: updated });
  return updated;
}

// src/features/sidepanel/modules/options.ts
async function initOptionsPanel() {
  const optionsPanel = document.getElementById("options-panel");
  const optionsBtn = document.getElementById("options-toggle-btn");
  const autoHighlightCheck = document.getElementById("auto-highlight-check");
  const themeSelect = document.getElementById("theme-select");
  if (optionsPanel && optionsBtn && autoHighlightCheck && themeSelect) {
    const settings = await getSettings();
    autoHighlightCheck.checked = true;
    autoHighlightCheck.disabled = true;
    if (!settings.autoHighlight) {
      await saveSettings({ autoHighlight: true });
    }
    themeSelect.value = settings.theme || "system";
    applyTheme(settings.theme || "system");
    optionsPanel.hidden = true;
    optionsBtn.setAttribute("aria-expanded", "false");
    optionsBtn.addEventListener("click", () => {
      optionsPanel.hidden = !optionsPanel.hidden;
      optionsBtn.setAttribute("aria-expanded", String(!optionsPanel.hidden));
    });
    themeSelect.addEventListener("change", async () => {
      const newTheme = themeSelect.value;
      await saveSettings({ theme: newTheme });
      applyTheme(newTheme);
    });
    const purgeBtn = document.getElementById("purge-btn");
    if (purgeBtn) {
      purgeBtn.addEventListener("click", purgePageBookmarks);
    }
    const purgeAllBtn = document.getElementById("purge-all-btn");
    if (purgeAllBtn) {
      purgeAllBtn.addEventListener("click", purgeAllBookmarks);
    }
  }
}

// src/features/sidepanel/sidepanel.ts
document.addEventListener("DOMContentLoaded", async () => {
  await initOptionsPanel();
  await syncSidepanelWithTab();
  chrome.tabs.onActivated.addListener(() => {
    syncSidepanelWithTab();
  });
  chrome.tabs.onUpdated.addListener((_tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete" && tab.active) {
      syncSidepanelWithTab();
    }
  });
  const searchInput = document.getElementById("search-input");
  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      const query = e.target.value;
      loadBookmarks(query);
    });
  }
  const filterDate = document.getElementById("filter-date");
  const filterChat = document.getElementById("filter-chat");
  if (filterDate) {
    filterDate.addEventListener("change", () => loadBookmarks());
  }
  if (filterChat) {
    filterChat.addEventListener("change", () => loadBookmarks());
  }
  document.getElementById("scope-current")?.addEventListener("click", () => setBookmarkScope("current"));
  document.getElementById("scope-library")?.addEventListener("click", () => setBookmarkScope("library"));
  document.getElementById("back-to-current-btn")?.addEventListener("click", () => setBookmarkScope("current"));
  const filterPopover = document.getElementById("filter-popover");
  const filterToggleBtn = document.getElementById("filter-toggle-btn");
  if (filterPopover && filterToggleBtn) {
    filterToggleBtn.addEventListener("click", () => {
      filterPopover.hidden = !filterPopover.hidden;
      filterToggleBtn.setAttribute("aria-expanded", String(!filterPopover.hidden));
    });
  }
  document.getElementById("show-all-btn")?.addEventListener("click", async () => {
    const db = await initDB();
    const bookmarks = await db.getAll("bookmarks");
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const currentTab = tabs[0];
      if (!currentTab || !currentTab.url)
        return;
      const currentUrl = currentTab.url;
      const tabId = currentTab.id;
      const relevantBookmarks = bookmarks.filter((b) => urlsReferToSameThread(currentUrl, b.threadId));
      if (relevantBookmarks.length > 0 && tabId !== undefined) {
        chrome.tabs.sendMessage(tabId, {
          type: "HIGHLIGHT_BATCH",
          payload: { bookmarks: relevantBookmarks }
        });
      }
    });
  });
});
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "BOOKMARK_SAVED") {
    loadBookmarks(undefined, true);
  }
});
